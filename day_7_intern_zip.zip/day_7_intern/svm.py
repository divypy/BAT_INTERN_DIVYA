from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

# Load the MNIST dataset
mnist = datasets.load_digits()

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(mnist.data, mnist.target, test_size=0.2, random_state=42)

# Initialize the SVM classifier
svm_classifier = SVC(kernel='linear')  # You can choose different kernels: 'linear', 'rbf', 'poly', etc.

# Train the SVM classifier
svm_classifier.fit(X_train, y_train)

# Predict labels for the test set
predicted = svm_classifier.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, predicted)
print(f"Accuracy of SVM Classifier on MNIST Dataset: {accuracy:.2f}")

# Display some test images with their predicted labels as text
fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(10, 4))

for i, ax in enumerate(axes.flat):
    ax.imshow(X_test[i].reshape(8, 8), cmap='gray')
    ax.set_title(f"Predicted: {predicted[i]}")
    ax.axis('off')

plt.tight_layout()
plt.show()
